<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="微信图片_20231217174231" tilewidth="32" tileheight="32" tilecount="1584" columns="32">
 <image source="微信图片_20231217174231.jpg" width="1024" height="712"/>
</tileset>
