<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="map" tilewidth="32" tileheight="32" tilecount="1584" columns="32">
 <image source="map.jpg" width="1024" height="712"/>
</tileset>
